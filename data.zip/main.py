from flask import Flask, render_template, redirect
from data import db_session
from data.news import Jobs
from data.users import User
from data import db_session
from forms.user import RegisterForm


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'



@app.route("/")
def index():
    db_session.global_init("db/mars_explorer.db")
    db_sess = db_session.create_session()
    job = db_sess.query(Jobs)
    return render_template("index.html", job=job)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')



if __name__ == '__main__':
    main()